<?php
// Theme Name
$name = 'Dolphin';

// Theme Author
$author = 'Pricop Alexandru - Mihai';

// Theme URL
$url = 'http://www.phpdolphin.com/';

// Theme Version
$version = '1.1.1';
?>
